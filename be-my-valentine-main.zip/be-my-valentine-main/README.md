# How to Pull a Baddie This Valentine's Day

Welcome to the ultimate guide to charm your way into someone's heart with a web app that's as cheeky as you are. This isn't just a project—it's your ticket to Valentine's Day success. You're welcome ;)\
Made using simple HTML/CSS, JavaScript, Anime.js, Tailwind CSS

## Why This Pulls Baddies

- **Runaway "No" Button**: Because who likes rejection? Watch the "No" button run for its life on hover or click
- **Hilarious Responses**: The app fights for your love with escalating levels of desperation
- **Smooth AF Animations**: For that extra wow factor

## How to Use

Click [Use this template](https://github.com/new?template_name=be-my-valentine&template_owner=aditisins) and it will create a new repo not a fork with all the files of this project for you.

## What's Inside

```
.
├── index.html        
├── script.js        
├── style.css         
├── images/           
└── sounds/           
```

## Customize It

- **Change the messages**: Update the `messages` array in `script.js` to match your love language
- **Add more pics/ change the sound**: Toss new images into the `images` folder and update `imagePaths` or add another mp3 file for button click sounds.
- **Tweak styles**: Go wild in `style.css` or tweak Tailwind classes in `index.html`

## License

MIT License, baby. Do whatever you want with it—spread the love.

Go get your baddie. You got this.


